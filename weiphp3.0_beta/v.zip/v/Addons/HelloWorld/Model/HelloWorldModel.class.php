<?php

namespace Addons\HelloWorld\Model;
use Think\Model;

/**
 * HelloWorld模型
 */
class HelloWorldModel extends Model{

}
