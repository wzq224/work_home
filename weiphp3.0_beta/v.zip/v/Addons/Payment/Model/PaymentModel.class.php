<?php

namespace Addons\Payment\Model;
use Think\Model;

/**
 * Payment模型
 */
class PaymentModel extends Model{

}
