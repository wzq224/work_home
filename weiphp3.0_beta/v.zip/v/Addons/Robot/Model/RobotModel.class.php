<?php

namespace Addons\Robot\Model;
use Think\Model;

/**
 * Robot模型
 */
class RobotModel extends Model{

}
