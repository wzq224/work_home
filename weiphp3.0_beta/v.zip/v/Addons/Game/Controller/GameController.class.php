<?php

namespace Addons\Game\Controller;
use Home\Controller\AddonsController;

class GameController extends AddonsController{

}
