<?php

namespace Addons\Chat\Controller;
use Home\Controller\AddonsController;

class ChatController extends AddonsController{

}
