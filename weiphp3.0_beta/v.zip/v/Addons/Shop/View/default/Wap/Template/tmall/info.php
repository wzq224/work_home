<?php
return array (
		'title' => '仿天猫',
		'author' => 'jacy',
		'desc' => 'banner图片规格是640x300 分类图标是60x60或以上规格正方形白色图标'
);					