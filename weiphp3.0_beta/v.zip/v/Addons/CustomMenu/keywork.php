<?php
return array (
		'view' => 'CustomMenu' 
);
					