<?php

namespace Addons\DeveloperTool\Model;
use Think\Model;

/**
 * DeveloperTool模型
 */
class DeveloperToolModel extends Model{

}
