<?php
return array (
		'title' => '默认风格',
		'author' => 'jacy',
		'desc' => ''
);					